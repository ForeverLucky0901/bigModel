<template>
  <router-view />
</template>

<script setup>
// App根组件
</script>
